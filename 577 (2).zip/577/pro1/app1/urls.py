from django.urls import path

from . import views
app_name='app1'

urlpatterns=[
    path('index/',views.index,name='index'),
    path('cr/',views.cr,name='cr'),
    path('lr/',views.lr,name='lr'),
    path('fun_t1/',views.fun_t1,name='fun_t1'),
    path('fun_t2/',views.fun_t2,name='fun_t2'),
]