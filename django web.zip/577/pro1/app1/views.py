from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
# Create your views here.
def  cr(request):
    return  HttpResponse("i amn learning!")
def lr(request):
    return  HttpResponse("i am working!")
def fun_t1(request):
    template=loader.get_template("t1.html")
    return HttpResponse(template.render())
def fun_t2(request):
    template=loader.get_template("t2.html")
    return HttpResponse(template.render())
def index(request):
    return render(request, 'index.html')
