
from django.urls import path

from . import views
app_name='app2'

urlpatterns=[
   
    path('java/',views.java,name='java'),
    path('fun_t1/',views.fun_t1,name='fun_t1'),
    path('fun_t2/',views.fun_t2,name='fun_t2'),
    
]