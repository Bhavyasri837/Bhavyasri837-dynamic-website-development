from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse

def java(request):
    temp = '''
    <html>
    <head>
    </head>
    <body bgcolor="red">
        <h1>Welcome to Java</h1>
        <marquee>We are from IC batch.</marquee>
    </body>
    </html>
    '''
    return HttpResponse(temp)
def fun_t1(request):
    template=loader.get_template("t1.html")
    return HttpResponse(template.render())
def fun_t2(request):
    template=loader.get_template("t2.html")
    return HttpResponse(template.render())