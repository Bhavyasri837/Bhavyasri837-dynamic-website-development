from django.apps import AppConfig


class BoysConfig(AppConfig):
    name = 'boys'
