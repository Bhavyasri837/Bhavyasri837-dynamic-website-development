from django.urls import path
from.import views
app_name='boys'
urlpatterns=[
    path("shoaib/",views.shoaib,name='shoaib'),
    path("pranathi/",views.pranathi,name='pranathi'),
    path("navateja/",views.navateja_v,name='navateja'),
    path("pc/",views.pc_v,name='pc'),
    path("",views.index,name='index'),
    path("student_v/",views.student_v,name='student_v'),
]
