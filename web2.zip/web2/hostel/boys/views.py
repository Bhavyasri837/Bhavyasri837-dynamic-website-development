from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

# Create your views here.
def shoaib(request):
    return HttpResponse("i am from DS department")
def pranathi(request):
    return HttpResponse(" i am a student from DS")   
def navateja_v(request):
    temp=loader.get_template('navateja_t.html')
    return HttpResponse(temp.render())
def pc_v(request):
    temp=loader.get_template('pc_t.html')
    return HttpResponse(temp.render()) 
def index(request):
    temp=loader.get_template('index.html')
    return HttpResponse(temp.render()) 
from.models import Student
def student_v(request):
    ob=Student.objects.all().values()
    temp=loader.get_template('all_students.html')
    context={
        'data':ob,
    }
    return HttpResponse(temp.render(context))
