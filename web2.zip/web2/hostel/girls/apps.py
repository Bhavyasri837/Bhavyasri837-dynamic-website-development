from django.apps import AppConfig


class GirlsConfig(AppConfig):
    name = 'girls'
