from django.urls import path
from.import views
app_name='girls'
urlpatterns=[
    path("muskan/",views.muskan,name='muskan'),
    path("karishma/",views.karishma,name='karishma'),
    path("ameena/",views.ameena_v,name='ameena'),
    path("deepthi/",views.deepthi_v,name='deepthi'),
]