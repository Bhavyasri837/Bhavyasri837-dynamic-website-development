from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
# Create your views here.
def muskan(request):
    return HttpResponse("she is my friend")
def karishma(request):
    return HttpResponse("she is from Ds ")
def ameena_v(request):
    temp=loader.get_template('ameena_t.html')
    return HttpResponse(temp.render())
def deepthi_v(request):
    temp=loader.get_template('deepthi_t.html')
    return HttpResponse(temp.render())
    